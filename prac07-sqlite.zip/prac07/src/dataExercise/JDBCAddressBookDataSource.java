package dataExercise;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import java.util.TreeSet;


/**
 * Class for retrieving data from the XML file holding the address list.
 */
public class JDBCAddressBookDataSource implements AddressBookDataSource {

   public static final String CREATE_TABLE =
           "CREATE TABLE IF NOT EXISTS address ("
                   + "idx INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE," // from https://stackoverflow.com/a/41028314
                   + "name VARCHAR(50),"
                   + "street VARCHAR(30),"
                   + "suburb VARCHAR(20),"
                   + "phone VARCHAR(10),"
                   + "email VARCHAR(30)" + ");";

   private static final String INSERT_PERSON = "INSERT INTO address (name, street, suburb, phone, email) VALUES (?, ?, ?, ?, ?);";

   private static final String GET_NAMES = "SELECT name FROM address";

   private static final String GET_PERSON = "SELECT * FROM address WHERE name=?";

   private static final String DELETE_PERSON = "DELETE FROM address WHERE name=?";

   private static final String COUNT_ROWS = "SELECT COUNT(*) FROM address";

   private Connection connection;

   private PreparedStatement addPerson;

   private PreparedStatement getNameList;

   private PreparedStatement getPerson;

   private PreparedStatement deletePerson;

   private PreparedStatement rowCount;

   public JDBCAddressBookDataSource() {
      connection = DBConnection.getInstance();
      try {
         Statement st = connection.createStatement();
         st.execute(CREATE_TABLE);
         addPerson = connection.prepareStatement(INSERT_PERSON);
         getNameList = connection.prepareStatement(GET_NAMES);
         getPerson = connection.prepareStatement(GET_PERSON);
         deletePerson = connection.prepareStatement(DELETE_PERSON);
         rowCount = connection.prepareStatement(COUNT_ROWS);
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    * @see AddressBookDataSource#addPerson(Person)
    */
   public void addPerson(Person p) {
      try {
         addPerson.setString(1, p.getName());
         addPerson.setString(2, p.getStreet());
         addPerson.setString(3, p.getSuburb());
         addPerson.setString(4, p.getPhone());
         addPerson.setString(5, p.getEmail());
         addPerson.executeUpdate();

         /*
         Why do we use prepared statements? SQL Injection!

         $id = $_POST["id"];
         mysql_query($conn, "DELETE FROM orders WHERE id = $id);

         $id =  5
         DELETE FROM orders WHERE id = 5

         $id = 0; DELETE FROM users; --
         DELETE FROM orders WHERE id = 0; DELETE FROM users; --
         */

      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    * @see AddressBookDataSource#nameSet()
    */
   public Set<String> nameSet() {
      Set<String> names = new TreeSet<String>();
      ResultSet rs = null;

      try {
         rs = getNameList.executeQuery();
         while (rs.next()) {
            names.add(rs.getString(1));
         }
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
      return names;
   }

   /**
    * @see AddressBookDataSource#getPerson(String)
    */
   public Person getPerson(String name) {
      try {
         // send the query off
         getPerson.setString(1, name);

         // get the data back
         ResultSet rs = getPerson.executeQuery();
         if (!rs.next()) {
            // a person with this name does not exist
            return null;
         }

         // construct the new person from the row
         return new Person(
                 rs.getString("name"),
                 rs.getString("street"),
                 rs.getString("suburb"),
                 rs.getString("phone"),
                 rs.getString("email"));

      } catch (SQLException ex) {
         ex.printStackTrace();
         return null;
      }
   }

   /**
    * @see AddressBookDataSource#getSize()
    */
   public int getSize() {
      ResultSet rs = null;
      int rows = 0;

      try {
         rs = rowCount.executeQuery();
         rs.next();
         rows = rs.getInt(1);
      } catch (SQLException ex) {
         ex.printStackTrace();
      }

      return rows;
   }

   /**
    * @see AddressBookDataSource#deletePerson(String)
    */
   public void deletePerson(String name) {
      try {
         deletePerson.setString(1, name);
         deletePerson.executeUpdate();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    * @see AddressBookDataSource#close()
    */
   public void close() {
      try {
         connection.close();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }
}
