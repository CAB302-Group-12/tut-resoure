package networkExercise;

import common.AddressBookDataSource;
import common.Person;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class NetworkDataSource implements AddressBookDataSource {
    private static final String HOSTNAME = "127.0.0.1";
    private static final int PORT = 10000;

    /**
     * These are the commands which will be sent across the network connection.
     */
    public enum Command {
        ADD_PERSON,
        GET_PERSON,
        DELETE_PERSON,
        GET_SIZE,
        GET_NAME_SET
    }

    private Socket connectToServer() throws IOException {
        return new Socket(HOSTNAME, PORT);
    }

    @Override
    public void addPerson(Person p) {
        if (p == null)
            throw new IllegalArgumentException("Person cannot be null");

        try (Socket socket = connectToServer()) {
            try (ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {
                // tell the server to expect a person's details
                outputStream.writeObject(Command.ADD_PERSON);

                // send the actual data
                outputStream.writeObject(p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Person getPerson(String name) {
        try (Socket socket = connectToServer()) {
            try (ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {
                // tell the server to expect a person's name, and send us back their details
                outputStream.writeObject(Command.GET_PERSON);
                outputStream.writeObject(name);

                // flush because if we don't, the request might not get sent yet, and we're waiting for a response
                outputStream.flush();

                // read the person's details back from the server
                try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
                    return (Person)inputStream.readObject();
                }
            }
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public int getSize() {
        /**
         * Protocol documentation might look like:
         * GET_SIZE:
         *  - No parameters
         *
         * Server responds with:
         *   - (int) number of entries
         */
        try (Socket socket = connectToServer()) {
            try (ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {
                outputStream.writeObject(Command.GET_SIZE);
                outputStream.flush();

                // read the person's details back from the server
                try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
                    return inputStream.readInt();
                }
            }
        } catch (IOException | ClassCastException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public void deletePerson(String name) {
        /**
         * Protocol documentation might look like:
         * DELETE_PERSON:
         *  - (String) the person to remove
         *
         * Server does not respond.
         */

        try (Socket socket = connectToServer()) {
            try (ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {
                outputStream.writeObject(Command.DELETE_PERSON);
                outputStream.writeObject(name);
            }
        } catch (IOException | ClassCastException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() {
    }

    @Override
    public Set<String> nameSet() {
        try (Socket socket = connectToServer()) {
            try (ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {
                outputStream.writeObject(Command.GET_NAME_SET);
                outputStream.flush();

                try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
                    return (Set<String>) inputStream.readObject();
                }
            }
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            e.printStackTrace();
            return new HashSet<>();
        }
    }
}
