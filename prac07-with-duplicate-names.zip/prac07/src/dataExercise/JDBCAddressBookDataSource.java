package dataExercise;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


/**
 * Class for retrieving data from the XML file holding the address list.
 */
public class JDBCAddressBookDataSource implements AddressBookDataSource {

   public static final String CREATE_TABLE =
           "CREATE TABLE IF NOT EXISTS address ("
                   + "idx INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL UNIQUE," // from https://stackoverflow.com/a/41028314
                   + "name VARCHAR(50),"
                   + "street VARCHAR(30),"
                   + "suburb VARCHAR(30),"
                   + "phone VARCHAR(10),"
                   + "email VARCHAR(100)" + ");";

   private static final String INSERT_PERSON = "INSERT INTO address (name, street, suburb, phone, email) VALUES (?, ?, ?, ?, ?);";

   private static final String UPDATE_PERSON = "UPDATE address SET name = ?, street = ?, suburb = ?, phone = ?, email = ? WHERE idx = ?);";

   private static final String GET_NAMES = "SELECT idx, name FROM address";

   private static final String GET_PERSON = "SELECT * FROM address WHERE idx=?";

   private static final String GET_INSERT_ID = "SELECT LAST_INSERT_ID();";

   private static final String DELETE_PERSON = "DELETE FROM address WHERE idx=?";

   private static final String COUNT_ROWS = "SELECT COUNT(*) FROM address";

   private Connection connection;

   private PreparedStatement addPerson;

   private PreparedStatement getNameList;

   private PreparedStatement getPerson;

   private PreparedStatement updatePerson;

   private PreparedStatement getInsertId;

   private PreparedStatement deletePerson;

   private PreparedStatement rowCount;

   public JDBCAddressBookDataSource() {
      connection = DBConnection.getInstance();
      try {
         Statement st = connection.createStatement();
         st.execute(CREATE_TABLE);

         addPerson = connection.prepareStatement(INSERT_PERSON);
         getNameList = connection.prepareStatement(GET_NAMES);
         getPerson = connection.prepareStatement(GET_PERSON);
         updatePerson = connection.prepareStatement(UPDATE_PERSON);
         getInsertId = connection.prepareStatement(GET_INSERT_ID);
         deletePerson = connection.prepareStatement(DELETE_PERSON);
         rowCount = connection.prepareStatement(COUNT_ROWS);
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    * @see AddressBookDataSource#addPerson(Person)
    */
   @Override
   public void addPerson(Person p) {
      try {
         addPerson.setString(1, p.getName());
         addPerson.setString(2, p.getStreet());
         addPerson.setString(3, p.getSuburb());
         addPerson.setString(4, p.getPhone());
         addPerson.setString(5, p.getEmail());
         addPerson.executeUpdate();

         final ResultSet rs = getInsertId.executeQuery();
         rs.next();
         p.setId(rs.getInt(1));
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }


   /**
    * @see AddressBookDataSource#addPerson(Person)
    */
   @Override
   public void updatePerson(Person p) {
      try {
         updatePerson.setString(1, p.getName());
         updatePerson.setString(2, p.getStreet());
         updatePerson.setString(3, p.getSuburb());
         updatePerson.setString(4, p.getPhone());
         updatePerson.setString(5, p.getEmail());
         updatePerson.setInt(6, p.getId());
         updatePerson.executeUpdate();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    * @see AddressBookDataSource#nameSet()
    */
   @Override
   public List<PersonEntry> nameList() {
      ArrayList<PersonEntry> names = new ArrayList<>();
      ResultSet rs = null;

      try {
         rs = getNameList.executeQuery();
         while (rs.next()) {
            names.add(new PersonEntry(
                    rs.getInt(1),   // id
                    rs.getString(2) // name
           ));
         }
      } catch (SQLException ex) {
         ex.printStackTrace();
      }

      return names;
   }

   @Override
   public Person getPerson(int idx) {
      try {
         getPerson.setInt(1, idx);
         final ResultSet rs = getPerson.executeQuery();
         if (!rs.next()) {
            // no person matched this name
            return null;
         }

         return new Person(
            rs.getInt("idx"),
            rs.getString("name"),
            rs.getString("street"),
            rs.getString("suburb"),
            rs.getString("phone"),
            rs.getString("email")
         );
      } catch (SQLException ex) {
         ex.printStackTrace();
         return null;
      }
   }

   /**
    * @see AddressBookDataSource#getSize()
    */
   @Override
   public int getSize() {
      ResultSet rs = null;
      int rows = 0;

      try {
         rs = rowCount.executeQuery();
         rs.next();
         rows = rs.getInt(1);
      } catch (SQLException ex) {
         ex.printStackTrace();
      }

      return rows;
   }

   /**
    * @see AddressBookDataSource#deletePerson(String)
    */
   @Override
   public void deletePerson(int id) {
      try {
         deletePerson.setInt(1, id);
         deletePerson.executeUpdate();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    * @see AddressBookDataSource#close()
    */
   @Override
   public void close() {
      try {
         connection.close();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }
}
