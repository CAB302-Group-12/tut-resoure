package dataExercise;

import javax.swing.DefaultListModel;
import javax.swing.ListModel;
import java.util.List;

/**
 * This version uses an AddressBookDataSource and its methods to retrieve data
 * 
 * @author Malcolm Corney
 * @version $Id: Exp $
 * 
 */
public class AddressBookData {

   DefaultListModel listModel;
   AddressBookDataSource addressData;
   List<PersonEntry> nameList;

   /**
    * Constructor initializes the list model that holds names as Strings and
    * attempts to read any data saved from previous invocations of the
    * application.
    * 
    */
   public AddressBookData() {
      listModel = new DefaultListModel();
      addressData = new JDBCAddressBookDataSource();
      nameList = addressData.nameList();

      // add the retrieved data to the list model
      for (PersonEntry entry : nameList) {
         listModel.addElement(entry.getName());
      }
   }

   /**
    * Adds a person to the address book.
    * 
    * @param p A Person to add to the address book.
    */
   public void add(Person p) {
      if (p.getId() == 0) {
         // this person does not exist in the database yet
         addressData.addPerson(p);
         nameList.add(new PersonEntry(p.getId(), p.getName()));
         listModel.addElement(p.getName());
         return;
      }

      addressData.updatePerson(p);
   }

   /**
    * Based on the name of the person in the address book, delete the person.
    * 
    * @param key
    */
   public void removeByIndex(int index) {
      // remove from both list and map
      int personId = nameList.get(index).getId();
      nameList.remove(index);
      listModel.removeElementAt(index);
      addressData.deletePerson(personId);
   }

   /**
    * Saves the data in the address book using a persistence
    * mechanism.
    */
   public void persist() {
      addressData.close();
   }

   /**
    * Retrieves Person details from the model.
    * 
    * @param key the name to retrieve.
    * @return the Person object related to the name.
    */
   public Person get(Object key) {
      return addressData.getPerson((int) key);
   }

   public Person getByIndex(int index) {
      int personId = nameList.get(index).getId();
      return addressData.getPerson(personId);
   }

   /**
    * Accessor for the list model.
    * 
    * @return the listModel to display.
    */
   public ListModel getModel() {
      return listModel;
   }

   /**
    * @return the number of names in the Address Book.
    */
   public int getSize() {
      return addressData.getSize();
   }
}
